import os
import requests
from typing import Dict, Any
from dotenv import load_dotenv

load_dotenv()

AUTOGOPAY_API_KEY = os.getenv("AUTOGOPAY_API_KEY")
AUTOGOPAY_BASE_URL = os.getenv("AUTOGOPAY_BASE_URL", "https://v1-gateway.autogopay.site")

HEADERS = {
    "Authorization": f"Bearer {AUTOGOPAY_API_KEY}",
    "Content-Type": "application/json"
}

def generate_qris(amount: int) -> Dict[str, Any]:
    url = f"{AUTOGOPAY_BASE_URL}/qris/generate"
    payload = {"amount": amount}
    response = requests.post(url, json=payload, headers=HEADERS, timeout=30)
    response.raise_for_status()
    result = response.json()
    if not result.get("success"):
        raise Exception(result.get("message"))
    data = result["data"]
    return {
        "transaction_id": data["transaction_id"],
        "order_id": data["order_id"],
        "amount": data["amount"],
        "qr_string": data["qr_string"],
        "qr_url": data["qr_url"],
        "checkout_url": data["checkout_url"],
        "expiry_time": data["expiry_time"]
    }

def check_qris_status(transaction_id: str) -> Dict[str, Any]:
    url = f"{AUTOGOPAY_BASE_URL}/qris/status"
    response = requests.post(url, json={"transaction_id": transaction_id}, headers=HEADERS, timeout=30)
    response.raise_for_status()
    return response.json()

def cancel_qris(transaction_id: str) -> Dict[str, Any]:
    url = f"{AUTOGOPAY_BASE_URL}/qris/cancel"
    response = requests.post(url, json={"transaction_id": transaction_id}, headers=HEADERS, timeout=30)
    response.raise_for_status()
    return response.json()