import os
import asyncio
import re
import io
import qrcode
import time
import threading
from datetime import datetime, timedelta
import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

from supabase_client import supabase_admin
import autogopay_client as agp

load_dotenv()

# ---------------------- KONFIGURASI ----------------------
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
ADMIN_IDS = [int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip()]

LOG_DEPOSIT_MASUK_ID    = int(os.getenv("LOG_DEPOSIT_MASUK_ID", 0))
LOG_TRANSAKSI_KELUAR_ID = int(os.getenv("LOG_TRANSAKSI_KELUAR_ID", 0))
LOG_DEPOSIT_GT_ID       = int(os.getenv("LOG_DEPOSIT_GT_ID", 0))
STOCK_ALERT_CHANNEL_ID  = int(os.getenv("STOCK_ALERT_CHANNEL_ID", 0))
BOT_STATUS_CHANNEL_ID   = int(os.getenv("BOT_STATUS_CHANNEL_ID", 0))
QRIS_LOG_CHANNEL_ID     = int(os.getenv("QRIS_LOG_CHANNEL_ID", 0))
QRIS_PENDING_CHANNEL_ID = int(os.getenv("QRIS_PENDING_CHANNEL_ID", 0))

STORE_NAME    = os.getenv("STORE_NAME", "NamoohStore")
GUILD_ID      = int(os.getenv("GUILD_ID", 0))

# ----- Ambil deposit_bot dari config atau environment -----
def get_deposit_bot():
    try:
        config = supabase_admin.table("config").select("value").eq("key", "deposit_bot").execute()
        if config.data and config.data[0].get("value"):
            return config.data[0]["value"]
    except:
        pass
    return os.getenv("DEPOSIT_BOT", "BotName")

def set_deposit_bot(name: str):
    supabase_admin.table("config").upsert({"key": "deposit_bot", "value": name}).execute()

# ----- Ambil deposit_world dari config atau environment -----
def get_deposit_world():
    try:
        config = supabase_admin.table("config").select("value").eq("key", "deposit_world").execute()
        if config.data and config.data[0].get("value"):
            return config.data[0]["value"]
    except:
        pass
    return os.getenv("DEPOSIT_WORLD", "YOURWORLD")

def set_deposit_world(name: str):
    supabase_admin.table("config").upsert({"key": "deposit_world", "value": name}).execute()

# ----- Ambil deposit_owner dari config atau environment -----
def get_deposit_owner():
    try:
        config = supabase_admin.table("config").select("value").eq("key", "deposit_owner").execute()
        if config.data and config.data[0].get("value"):
            return config.data[0]["value"]
    except:
        pass
    return os.getenv("DEPOSIT_OWNER", "OwnerName")

def set_deposit_owner(name: str):
    supabase_admin.table("config").upsert({"key": "deposit_owner", "value": name}).execute()

# ----- Ambil rate_dl dari config atau default -----
def get_rate_dl():
    try:
        config = supabase_admin.table("config").select("value").eq("key", "rate_dl").execute()
        if config.data and config.data[0].get("value"):
            return int(config.data[0]["value"])
    except:
        pass
    return 295

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents)

# ---------------------- COOLDOWNS ----------------------
cooldown_buy = {}
cooldown_qris = {}
cooldown_balance = {}
cooldown_deposit = {}
cooldown_setgrowid = {}
cooldown_interaction = {}
store_refresh_tasks = {}

# ====================== STORE PANEL PERSISTENCE (Supabase) ======================
def db_save_panel(channel_id: int, message_id: int):
    """Simpan channel_id + message_id panel store ke Supabase supaya tetap
    ada walau bot restart. Pakai upsert berdasarkan channel_id (unique)."""
    try:
        supabase_admin.table("store_panels").upsert(
            {"channel_id": channel_id, "message_id": message_id, "updated_at": datetime.now().isoformat()},
            on_conflict="channel_id"
        ).execute()
    except Exception as e:
        print(f"[PANEL DB] Gagal simpan panel: {e}")

def db_delete_panel(channel_id: int):
    try:
        supabase_admin.table("store_panels").delete().eq("channel_id", channel_id).execute()
    except Exception as e:
        print(f"[PANEL DB] Gagal hapus panel: {e}")

async def restore_panels_from_db():
    """Dipanggil di on_ready — reload semua panel store yang tersimpan di DB."""
    try:
        rows = supabase_admin.table("store_panels").select("*").execute()
        for row in (rows.data or []):
            ch_id  = row["channel_id"]
            msg_id = row["message_id"]
            channel = bot.get_channel(ch_id)
            if not channel:
                continue
            try:
                msg = await channel.fetch_message(msg_id)
                store_refresh_tasks[ch_id] = (None, msg)
                print(f"[PANEL] Restored panel di channel {ch_id} (msg {msg_id})")
            except discord.NotFound:
                print(f"[PANEL] Panel {msg_id} di channel {ch_id} tidak ditemukan, dihapus dari DB")
                db_delete_panel(ch_id)
            except Exception as e:
                print(f"[PANEL] Error restore panel {ch_id}: {e}")
    except Exception as e:
        print(f"[PANEL DB] Gagal restore panels: {e}")
status_message_cache = {}

COOLDOWN_SECONDS = 60

def check_cooldown(cooldown_dict, user_id):
    last = cooldown_dict.get(user_id, 0)
    remaining = COOLDOWN_SECONDS - (time.time() - last)
    return max(0, remaining)

def set_cooldown(cooldown_dict, user_id):
    cooldown_dict[user_id] = time.time()

# ---------------------- HELPER FUNCTIONS ----------------------
def get_or_create_user(discord_id):
    existing = supabase_admin.table("users").select("*").eq("discord_id", discord_id).execute()
    if existing.data:
        return existing.data[0]
    new = supabase_admin.table("users").insert({"discord_id": discord_id, "balance_wl": 0}).execute()
    return new.data[0]

def is_admin(user_id):
    if user_id in ADMIN_IDS:
        return True
    role = supabase_admin.table("user_roles").select("role").eq("user_id", user_id).execute()
    return role.data and role.data[0].get("role") == "admin"

def is_blacklisted(user_id):
    result = supabase_admin.table("blacklist").select("user_id").eq("user_id", user_id).execute()
    return len(result.data) > 0

def wl_display(wl):
    dl, rem = divmod(wl, 100)
    if dl > 0 and rem > 0:
        return f"**{dl} DL {rem} WL** `({wl} WL)`"
    if dl > 0:
        return f"**{dl} DL** `({wl} WL)`"
    return f"**{wl} WL**"

def rp_display(rp):
    return f"{rp:,}".replace(",", ".")

def get_emoji(name, fallback):
    guild = bot.get_guild(GUILD_ID)
    emoji_source = guild.emojis if guild else bot.emojis
    emoji = discord.utils.get(emoji_source, name=name)
    return str(emoji) if emoji else fallback

def format_order_id(order_id):
    if order_id and order_id.startswith("AUTOGOPAY-"):
        return order_id.replace("AUTOGOPAY-", "")
    return order_id

async def get_all_products_with_stock():
    products = supabase_admin.table("products").select("*").execute()
    for p in products.data:
        count = supabase_admin.table("stock_items").select("id", count="exact").eq("product_id", p["id"]).execute()
        p["stock_total"] = count.count if count.count is not None else 0
    return products.data

# ====================== STORE EMBED ======================
def store_embed(prods):
    growtopia_emoji = get_emoji("growtopia", "🌍")
    jam_emoji       = get_emoji("jam", "🕒")
    status_emoji    = get_emoji("status", "📌")
    diamond_emoji   = get_emoji("diamondlock", "💎")
    box_emoji       = get_emoji("box", "📦")
    arrow_emoji     = get_emoji("bluearrow", "➡️")
    wl_emoji        = get_emoji("worldlock", "🔒")
    book_emoji      = get_emoji("book", "📖")
    crown_emoji     = get_emoji("crown", "👑")
    SEP = "▬" * 12

    rate = get_rate_dl()

    desc = f"{growtopia_emoji} **GROWTOPIA ACCOUNT** {growtopia_emoji}\n"
    desc += SEP + "\n"
    desc += f"{jam_emoji} Last Update: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n"
    desc += f"{status_emoji} Rate 1 {diamond_emoji} = Rp.{rp_display(rate)}\n"
    desc += SEP + "\n"

    for p in prods:
        name = p['name'].upper()
        code = p.get('code') or p['name']
        stok = p.get('stock_total', 0)
        if stok is None: stok = 0
        price_wl = p['price_wl']
        if price_wl is None: price_wl = 0
        sold = p['sold_count']
        if sold is None: sold = 0
        description = p.get('description', '')

        desc += f"{box_emoji} **{name}** {box_emoji}\n"
        desc += f"{arrow_emoji} Code: `{code}`\n"
        desc += f"{arrow_emoji} Stock: `{stok}`\n"
        desc += f"{arrow_emoji} Price: {price_wl} {wl_emoji}\n"
        desc += f"{arrow_emoji} Sold: `{sold}`\n"
        if description:
            desc += f"{book_emoji} Info: {description} {crown_emoji}\n"
        desc += SEP + "\n"

    if len(desc) > 4000:
        desc = desc[:3997] + "..."

    embed = discord.Embed(color=0x2ecc71, description=desc)
    embed.set_footer(text="Set GrowID dulu → Deposit DL/WL atau Topup QRIS → Beli produk")
    embed.set_image(url="https://files.catbox.moe/qnohu7.gif")
    return embed

async def refresh_all_stores():
    dead = []
    for ch_id, (task, msg) in list(store_refresh_tasks.items()):
        try:
            prods = await get_all_products_with_stock()
            new_embed = store_embed(prods)
            await msg.edit(embed=new_embed, view=StoreView(prods))
        except discord.NotFound:
            if task:
                task.cancel()
            dead.append(ch_id)
        except discord.HTTPException as e:
            if e.code == 50027 or e.status == 401:
                print(f"[REFRESH] Token expired di channel {ch_id}, kirim ulang")
                try:
                    channel = bot.get_channel(ch_id)
                    if channel:
                        new_msg = await channel.send(embed=new_embed, view=StoreView(prods))
                        store_refresh_tasks[ch_id] = (task, new_msg)
                        db_save_panel(ch_id, new_msg.id)
                    else:
                        if task:
                            task.cancel()
                        dead.append(ch_id)
                except Exception as e2:
                    print(f"[REFRESH] Gagal kirim ulang: {e2}")
                    if task:
                        task.cancel()
                    dead.append(ch_id)
            else:
                print(f"[REFRESH] HTTPException: {e}")
        except Exception as e:
            print(f"[REFRESH] Error: {e}")
    for ch_id in dead:
        store_refresh_tasks.pop(ch_id, None)
        db_delete_panel(ch_id)

# ====================== AUTO REFRESH LOOP (stock real-time) ======================
async def store_auto_refresh_loop():
    """Refresh semua panel /store yang aktif setiap STORE_REFRESH_INTERVAL detik."""
    interval = int(os.getenv("STORE_REFRESH_INTERVAL", 60))
    await bot.wait_until_ready()
    while True:
        try:
            if store_refresh_tasks:
                await refresh_all_stores()
        except Exception as e:
            print(f"[AUTO REFRESH] Error: {e}")
        await asyncio.sleep(interval)

# ---------------------- STATUS EMBED ----------------------
def make_status_embed(mode: str):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    color = {"WAITING FOR DEPOSIT CALL": 0x3498db, "DEPOSIT RECEIVED": 0x2ecc71, "RECONNECTING": 0xf1c40f, "OFFLINE": 0xe74c3c}.get(mode, 0x95a5a6)

    bot_emoji       = get_emoji("newg1", "🤖")
    world_emoji     = get_emoji("global", "🌍")
    jam_emoji       = get_emoji("jam", "⏳")
    done_emoji      = get_emoji("done", "✅")
    reconnect_emoji = get_emoji("reconnect", "🔄")
    offline_emoji   = get_emoji("eror", "🔴")

    icon = {
        "WAITING FOR DEPOSIT CALL": jam_emoji,
        "DEPOSIT RECEIVED": done_emoji,
        "RECONNECTING": reconnect_emoji,
        "OFFLINE": offline_emoji
    }.get(mode, "❓")

    deposit_bot   = get_deposit_bot()
    deposit_world = get_deposit_world()

    embed = discord.Embed(title=f"{world_emoji} DONATION BOX STATUS", color=color)
    embed.add_field(name=f"{bot_emoji} Bot",   value=f"`{deposit_bot}`",   inline=True)
    embed.add_field(name=f"{world_emoji} World", value=f"`{deposit_world}`", inline=True)
    embed.add_field(name=f"{icon} {mode}", value="\u200b", inline=False)
    embed.set_footer(text=f"{STORE_NAME} | {ts}")
    return embed

async def send_or_edit_status(mode: str):
    if not BOT_STATUS_CHANNEL_ID:
        return
    ch = bot.get_channel(BOT_STATUS_CHANNEL_ID)
    if not ch:
        return
    embed = make_status_embed(mode)
    cached = status_message_cache.get(BOT_STATUS_CHANNEL_ID)
    if cached:
        try:
            await cached.edit(embed=embed)
            return
        except:
            status_message_cache.pop(BOT_STATUS_CHANNEL_ID, None)
    try:
        msg = await ch.send(embed=embed)
        status_message_cache[BOT_STATUS_CHANNEL_ID] = msg
    except Exception as e:
        print(f"[Status] Gagal: {e}")

def compute_expired_text(expiry: str) -> str:
    try:
        exp_dt = datetime.fromisoformat(expiry.replace("Z", "+00:00"))
        now_dt = datetime.now(exp_dt.tzinfo) if exp_dt.tzinfo else datetime.now()
        delta_min = max(0, int((exp_dt - now_dt).total_seconds() // 60))
        return f"in {delta_min} minutes"
    except Exception:
        return expiry

# ====================== QRIS EMBED ======================
# --- PENDING ---
def make_qris_pending_embed(interaction: discord.Interaction, user: dict, txn_id: str, order_id: str,
                             rupiah: int, wl: int, rate_dl: int, expiry: str) -> discord.Embed:
    expired_text = compute_expired_text(expiry)
    display_order_id = format_order_id(order_id)

    jam_emoji     = get_emoji("jam", "🕐")
    status_emoji  = get_emoji("status", "📌")
    user_emoji    = get_emoji("user", "👤")
    global_emoji  = get_emoji("global", "🌍")
    arrow_emoji   = get_emoji("bluearrow", "➡️")
    balance_emoji = get_emoji("balance", "💰")
    wl_emoji      = get_emoji("worldlock", "🔒")

    embed = discord.Embed(title=f"{jam_emoji} Deposit — PENDING", color=0xf39c12)
    embed.add_field(name=f"{status_emoji} Status:", value=f"{jam_emoji} PENDING", inline=False)
    embed.add_field(name=f"{user_emoji} User:",    value=interaction.user.mention,        inline=False)
    embed.add_field(name=f"{global_emoji} GrowID:", value=f"`{user.get('grow_id')}`",     inline=False)
    embed.add_field(name=f"{arrow_emoji} Ref ID:",  value=f"`{txn_id}`",                  inline=False)
    embed.add_field(name=f"{arrow_emoji} Order ID:", value=f"`{display_order_id}`",        inline=False)
    embed.add_field(name=f"{balance_emoji} Amount:", value=f"IDR {rp_display(rupiah)}",    inline=False)
    embed.add_field(name=f"{wl_emoji} WL:",         value=str(wl),                         inline=False)
    embed.add_field(name=f"{status_emoji} Rate:",   value=f"1 DL = {rate_dl} IDR",         inline=False)
    embed.add_field(name=f"{jam_emoji} Expired:",   value=expired_text,                    inline=False)
    embed.set_footer(text=f"© {STORE_NAME} | {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    return embed

# --- DM QRIS (description-based) ---
def make_qris_dm_embed(txn_id: str, order_id: str, rupiah: int, wl: int, rate_dl: int, expiry: str) -> discord.Embed:
    expired_text = compute_expired_text(expiry)
    SEP = "▬" * 12
    display_order_id = format_order_id(order_id)

    qris_emoji    = get_emoji("QRIS", "💳")
    status_emoji  = get_emoji("status", "📌")
    arrow_emoji   = get_emoji("bluearrow", "➡️")
    balance_emoji = get_emoji("balance", "💰")
    jam_emoji     = get_emoji("jam", "🕐")
    done_emoji    = get_emoji("done", "✅")
    wl_emoji      = get_emoji("worldlock", "🔒")

    desc  = f"{qris_emoji} QRIS DEPOSITO {qris_emoji}\n"
    desc += f"{SEP}\n"
    desc += f"{status_emoji} **TRANSACTION DETAILS**\n"
    desc += f"{arrow_emoji} Reff ID  : `{txn_id}`\n"
    desc += f"{arrow_emoji} Order ID : `{display_order_id}`\n"
    desc += f"{SEP}\n"
    desc += f"{balance_emoji} **PAYMENT** {balance_emoji}\n"
    desc += f"{arrow_emoji} Amount   : IDR {rp_display(rupiah)}\n"
    desc += f"{SEP}\n"
    desc += f"{wl_emoji} **YANG KAMU DAPAT**\n"
    desc += f"{arrow_emoji} {wl} WL\n"
    desc += f"{arrow_emoji} Rate : 1 DL = {rate_dl} IDR\n"
    desc += f"{SEP}\n"
    desc += f"{jam_emoji} Expired in {expired_text}\n"
    desc += f"{SEP}\n"
    desc += f"{status_emoji} Scan QR di bawah untuk membayar.\n"
    desc += f"{done_emoji} Saldo otomatis masuk setelah pembayaran diterima."

    embed = discord.Embed(description=desc, color=0xe74c3c)
    embed.set_image(url="attachment://qris.png")
    return embed

# --- EXPIRED ---
def make_qris_expired_embed(txn_data: dict, user_id: int) -> discord.Embed:
    jam_emoji     = get_emoji("jam", "🕐")
    status_emoji  = get_emoji("status", "📌")
    user_emoji    = get_emoji("user", "👤")
    global_emoji  = get_emoji("global", "🌍")
    arrow_emoji   = get_emoji("bluearrow", "➡️")
    balance_emoji = get_emoji("balance", "💰")
    wl_emoji      = get_emoji("worldlock", "🔒")

    grow_id = "-"
    try:
        user_data = supabase_admin.table("users").select("grow_id").eq("discord_id", user_id).execute()
        if user_data.data and user_data.data[0].get("grow_id"):
            grow_id = user_data.data[0]["grow_id"]
    except:
        pass

    display_order_id = format_order_id(txn_data.get('order_id', 'N/A'))

    embed = discord.Embed(title=f"{jam_emoji} Deposit — EXPIRED", color=0xe74c3c)
    embed.add_field(name=f"{status_emoji} Status:", value="**EXPIRED**",                            inline=False)
    embed.add_field(name=f"{user_emoji} User:",     value=f"<@{user_id}>",                          inline=False)
    embed.add_field(name=f"{global_emoji} GrowID:", value=f"`{grow_id}`",                           inline=False)
    embed.add_field(name=f"{arrow_emoji} Ref ID:",  value=f"`{txn_data['autogopay_txn_id']}`",      inline=False)
    embed.add_field(name=f"{arrow_emoji} Order ID:", value=f"`{display_order_id}`",                 inline=False)
    embed.add_field(name=f"{balance_emoji} Amount:", value=f"IDR {rp_display(txn_data['amount'])}", inline=False)
    embed.add_field(name=f"{wl_emoji} WL:",         value=str(txn_data['wl_amount']),               inline=False)
    embed.add_field(name=f"{status_emoji} Rate:",   value=f"1 DL = {txn_data.get('rate_dl', 295)} IDR", inline=False)
    embed.set_footer(text=f"© {STORE_NAME} | {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    return embed

async def send_qris_pending_log(interaction: discord.Interaction, user: dict, txn_id: str, order_id: str,
                                 rupiah: int, wl: int, rate_dl: int, expiry: str):
    if not QRIS_PENDING_CHANNEL_ID:
        return
    ch = bot.get_channel(QRIS_PENDING_CHANNEL_ID)
    if not ch:
        print(f"[QRIS PENDING LOG] Channel {QRIS_PENDING_CHANNEL_ID} tidak ditemukan.")
        return
    embed = make_qris_pending_embed(interaction, user, txn_id, order_id, rupiah, wl, rate_dl, expiry)
    try:
        await ch.send(embed=embed)
    except Exception as e:
        print(f"[QRIS PENDING LOG] Gagal kirim embed: {e}")

# ====================== NOTIFIKASI EXPIRED ======================
async def send_expired_notification(txn_data: dict):
    user_id = txn_data['user_id']
    embed   = make_qris_expired_embed(txn_data, user_id)
    try:
        user = await bot.fetch_user(user_id)
        await user.send(embed=embed)
        print(f"[EXPIRED] DM expired dikirim ke user {user_id}")
    except Exception as e:
        print(f"[EXPIRED] Gagal kirim DM ke {user_id}: {e}")
    if QRIS_PENDING_CHANNEL_ID:
        ch = bot.get_channel(QRIS_PENDING_CHANNEL_ID)
        if ch:
            try:
                await ch.send(embed=embed)
            except Exception as e:
                print(f"[EXPIRED] Gagal kirim ke channel pending: {e}")

# ====================== CHECK EXPIRED (interval 15 menit) ======================
async def check_expired_transactions():
    while True:
        await asyncio.sleep(900)
        try:
            now = datetime.now().isoformat()
            expired_txs = supabase_admin.table("topup_transactions") \
                .select("*").eq("status", "pending").lt("expiry_time", now).execute()
            if expired_txs.data:
                for tx in expired_txs.data:
                    supabase_admin.table("topup_transactions") \
                        .update({"status": "expired"}).eq("id", tx["id"]).execute()
                    await send_expired_notification(tx)
                    print(f"[EXPIRED] Transaksi {tx['autogopay_txn_id']} expired")
        except Exception as e:
            print(f"[EXPIRED CHECK] Error: {e}")

class CancelDepositView(discord.ui.View):
    def __init__(self, txn_id: str, user_id: int):
        super().__init__(timeout=None)
        self.txn_id  = txn_id
        self.user_id = user_id

    @discord.ui.button(label="Cancel Deposit", style=discord.ButtonStyle.danger)
    async def cancel_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ Ini bukan deposit kamu.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        tx = supabase_admin.table("topup_transactions").select("*").eq("autogopay_txn_id", self.txn_id).execute()
        if not tx.data:
            await interaction.followup.send("❌ Transaksi tidak ditemukan.", ephemeral=True)
            return
        if tx.data[0]["status"] != "pending":
            await interaction.followup.send(
                f"⚠️ Deposit ini sudah **{tx.data[0]['status']}**, gak bisa dibatalkan lagi.", ephemeral=True)
            return
        try:
            agp.cancel_qris(self.txn_id)
        except Exception as e:
            print(f"[CANCEL QRIS] Gagal cancel di AutoGoPay ({self.txn_id}): {e}")
        supabase_admin.table("topup_transactions").update({"status": "cancelled"}) \
            .eq("autogopay_txn_id", self.txn_id).eq("status", "pending").execute()
        button.disabled = True
        button.label    = "Dibatalkan"
        cancelled_embed = discord.Embed(
            title="❌ QRIS Deposit Dibatalkan",
            description="Deposit ini sudah dibatalkan dan tidak bisa dibayar lagi.",
            color=discord.Color.dark_grey()
        )
        try:
            await interaction.message.edit(embed=cancelled_embed, view=self)
        except Exception as e:
            print(f"[CANCEL QRIS] Gagal edit message: {e}")
        await interaction.followup.send("✅ Deposit dibatalkan.", ephemeral=True)
        self.stop()

# ---------------------- MODALS ----------------------
class SetGrowIDModal(discord.ui.Modal, title="Set GrowID"):
    grow_input = discord.ui.TextInput(label="GrowID", placeholder="Contoh: MyGrowID123", min_length=3, max_length=18)
    async def on_submit(self, interaction: discord.Interaction):
        grow_id  = self.grow_input.value.strip()
        existing = supabase_admin.table("users").select("discord_id").ilike("grow_id", grow_id).execute()
        if existing.data and existing.data[0]["discord_id"] != interaction.user.id:
            await interaction.response.send_message(f"❌ GrowID `{grow_id}` sudah dipakai.", ephemeral=True)
            return
        supabase_admin.table("users").update({"grow_id": grow_id}).eq("discord_id", interaction.user.id).execute()
        await interaction.response.send_message(f"✅ GrowID di-set ke `{grow_id}`", ephemeral=True)

class QRISModal(discord.ui.Modal, title="Topup Saldo via QRIS"):
    amount_input = discord.ui.TextInput(label="Jumlah (IDR)", placeholder="Max 10jt", min_length=1, max_length=10)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        try:
            rupiah = int(self.amount_input.value.strip())
            if rupiah <= 0:
                await interaction.followup.send("❌ Jumlah harus lebih dari 0.", ephemeral=True)
                return
            if rupiah > 10_000_000:
                await interaction.followup.send("❌ Maksimal Rp10.000.000", ephemeral=True)
                return
        except ValueError:
            await interaction.followup.send("❌ Masukkan angka valid.", ephemeral=True)
            return

        user = get_or_create_user(interaction.user.id)
        if not user.get("grow_id"):
            await interaction.followup.send("❌ Set GrowID dulu!", ephemeral=True)
            return

        config = supabase_admin.table("config").select("value").eq("key", "rate_dl").execute()
        rate_dl = int(config.data[0]["value"]) if config.data else 295
        wl = (rupiah * 100) // rate_dl
        if wl == 0:
            min_idr = max(1, (rate_dl // 100) + 1)
            await interaction.followup.send(f"❌ Minimal Rp {min_idr} untuk 1 WL.", ephemeral=True)
            return

        try:
            qris_data = agp.generate_qris(rupiah)
            txn_id    = qris_data["transaction_id"]
            order_id  = qris_data["order_id"]
            qr_string = qris_data["qr_string"]
            expiry    = qris_data["expiry_time"]
            insert_result = supabase_admin.table("topup_transactions").insert({
                "user_id": interaction.user.id,
                "amount":  rupiah,
                "autogopay_txn_id": txn_id,
                "status":   "pending",
                "wl_amount": wl,
                "order_id":  order_id,
                "rate_dl":   rate_dl,
                "expiry_time": expiry
            }).execute()
            transaction_id = insert_result.data[0]['id']
        except Exception as e:
            await interaction.followup.send(f"❌ Gagal generate QRIS: {e}", ephemeral=True)
            return

        try:
            await send_qris_pending_log(interaction, user, txn_id, order_id, rupiah, wl, rate_dl, expiry)
        except Exception as e:
            print(f"[QRIS PENDING LOG] Error: {e}")

        qr = qrcode.QRCode(box_size=8, border=2)
        qr.add_data(qr_string)
        qr.make(fit=True)
        img       = qr.make_image(fill_color="black", back_color="white")
        img_bytes = io.BytesIO()
        img.save(img_bytes, format="PNG")
        img_bytes.seek(0)
        qr_file = discord.File(img_bytes, filename="qris.png")

        embed = make_qris_dm_embed(txn_id, order_id, rupiah, wl, rate_dl, expiry)
        view  = CancelDepositView(txn_id, interaction.user.id)

        try:
            dm_message = await interaction.user.send(embed=embed, file=qr_file, view=view)
            supabase_admin.table("topup_transactions").update({
                "dm_channel_id": dm_message.channel.id,
                "dm_message_id": dm_message.id
            }).eq("id", transaction_id).execute()
            await interaction.followup.send("✅ QRIS terkirim ke DM!", ephemeral=True)
        except discord.Forbidden:
            await interaction.followup.send("❌ Gagal kirim DM, buka DM saya.", ephemeral=True)

        cooldown_qris[interaction.user.id] = time.time()

class UpdatePriceModal(discord.ui.Modal, title="Update Harga Produk"):
    product_name = discord.ui.TextInput(label="Nama produk", required=True)
    new_price    = discord.ui.TextInput(label="Harga baru (WL)", required=True)
    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        if not is_admin(interaction.user.id):
            await interaction.followup.send("❌ Khusus admin.", ephemeral=True)
            return
        name = self.product_name.value.strip()
        try:
            price = int(self.new_price.value.strip())
            if price <= 0: raise ValueError
        except ValueError:
            await interaction.followup.send("❌ Harga harus angka positif.", ephemeral=True)
            return
        result = supabase_admin.table("products").update({"price_wl": price}).eq("name", name).execute()
        if not result.data:
            await interaction.followup.send(f"❌ Produk `{name}` tidak ditemukan.", ephemeral=True)
            return
        await interaction.followup.send(f"✅ Harga **{name}** diupdate ke `{price} WL`", ephemeral=True)
        await refresh_all_stores()

# ====================== QTY MODAL ======================
class QtyModal(discord.ui.Modal, title="Jumlah Pembelian"):
    qty_input = discord.ui.TextInput(label="Jumlah", placeholder="Contoh: 1", min_length=1, max_length=4)
    def __init__(self, product, view):
        super().__init__()
        self.product_id   = product['id']
        self.product_name = product['name']
        self.view         = view
        self.title        = f"Beli {product['name']}"

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        try:
            qty = int(self.qty_input.value.strip())
            if qty < 1: raise ValueError
        except ValueError:
            await interaction.followup.send("❌ Jumlah harus angka positif.", ephemeral=True)
            return

        prod = supabase_admin.table("products").select("*").eq("id", self.product_id).execute()
        if not prod.data:
            await interaction.followup.send("❌ Produk tidak ditemukan.", ephemeral=True)
            return
        product     = prod.data[0]
        stock_count = supabase_admin.table("stock_items").select("id", count="exact").eq("product_id", self.product_id).execute()
        if stock_count.count < qty:
            await interaction.followup.send(f"❌ Stok tidak cukup. Tersisa {stock_count.count}.", ephemeral=True)
            return
        user = supabase_admin.table("users").select("*").eq("discord_id", interaction.user.id).execute()
        if not user.data:
            await interaction.followup.send("❌ User tidak terdaftar.", ephemeral=True)
            return
        user        = user.data[0]
        total_price = product['price_wl'] * qty
        if user['balance_wl'] < total_price:
            await interaction.followup.send(f"❌ Saldo tidak cukup. Butuh {total_price} WL.", ephemeral=True)
            return
        stock_items = supabase_admin.table("stock_items").select("id, account_line").eq("product_id", self.product_id).limit(qty).execute()
        if len(stock_items.data) < qty:
            await interaction.followup.send("❌ Stok tidak cukup (race condition).", ephemeral=True)
            return
        account_lines = [item['account_line'] for item in stock_items.data]
        stock_ids     = [item['id'] for item in stock_items.data]
        try:
            supabase_admin.table("stock_items").delete().in_("id", stock_ids).execute()
            new_balance = user['balance_wl'] - total_price
            supabase_admin.table("users").update({"balance_wl": new_balance}).eq("discord_id", interaction.user.id).execute()
            supabase_admin.table("products").update({"sold_count": product['sold_count'] + qty}).eq("id", self.product_id).execute()
        except Exception as e:
            await interaction.followup.send(f"❌ Gagal memproses: {e}", ephemeral=True)
            return
        cooldown_buy[interaction.user.id] = time.time()
        try:
            content = "\n".join(account_lines)
            buf      = discord.File(io.BytesIO(content.encode()), filename=f"{product['name']}_akun.txt")
            dm_embed = discord.Embed(
                title=f"🎉 Pembelian Berhasil!",
                description=f"Produk: **{product['name']}** x{qty}\nTotal: **{total_price} WL**",
                color=0x2ecc71
            )
            dm_embed.set_image(url="https://files.catbox.moe/qnohu7.gif")
            await interaction.user.send(embed=dm_embed, file=buf)
            await interaction.followup.send("✅ Berhasil beli. Cek DM!", ephemeral=True)
        except discord.Forbidden:
            await interaction.followup.send("⚠️ Pembelian sukses tapi DM tertutup.", ephemeral=True)
        if LOG_TRANSAKSI_KELUAR_ID:
            ch = bot.get_channel(LOG_TRANSAKSI_KELUAR_ID)
            if ch:
                wl_emoji     = get_emoji("worldlock", "🔒")
                arrow_emoji  = get_emoji("bluearrow", "➡️")
                new_stock    = max(0, (stock_count.count or 0) - qty)
                log_embed = discord.Embed(title="🛒 Transaksi Keluar", color=0xe74c3c)
                log_embed.add_field(name="👤 User",            value=f"{interaction.user.mention}\n`{interaction.user.name}`", inline=True)
                log_embed.add_field(name="🌍 GrowID",          value=f"`{user.get('grow_id','?')}`", inline=True)
                log_embed.add_field(name="\u200b",             value="\u200b", inline=False)
                log_embed.add_field(name="📦 Produk",          value=f"`{product['name']}` x{qty}", inline=True)
                log_embed.add_field(name="💸 Total Bayar",     value=f"`{total_price} WL`", inline=True)
                log_embed.add_field(name="\u200b",             value="\u200b", inline=False)
                log_embed.add_field(name=f"{wl_emoji} Saldo Sebelum", value=wl_display(user['balance_wl']), inline=True)
                log_embed.add_field(name=f"{wl_emoji} Saldo Sesudah", value=wl_display(new_balance),        inline=True)
                log_embed.add_field(name="\u200b",             value="\u200b", inline=False)
                log_embed.add_field(name="📊 Sisa Stok",       value=f"`{new_stock}` item", inline=True)
                log_embed.set_footer(text=STORE_NAME)
                log_embed.timestamp = datetime.now()
                try:
                    await ch.send(embed=log_embed)
                except Exception as e:
                    print(f"[LOG TRANSAKSI] Gagal kirim: {e}")
        new_stock = stock_count.count - qty
        if STOCK_ALERT_CHANNEL_ID and new_stock <= 3:
            ch = bot.get_channel(STOCK_ALERT_CHANNEL_ID)
            if ch:
                await ch.send(f"⚠️ Stok **{product['name']}** tersisa {new_stock}!")
        await refresh_all_stores()

        if isinstance(self.view, StoreView):
            try:
                fresh_prods = await get_all_products_with_stock()
                new_view = StoreView(fresh_prods)
                await interaction.message.edit(view=new_view)
            except Exception as e:
                print(f"[QTY] Gagal reset view: {e}")

# ====================== PRODUCT DROPDOWN ======================
class ProductDropdown(discord.ui.Select):
    def __init__(self, products):
        shop_emoji = get_emoji("shop", "🛒")
        opts = [
            discord.SelectOption(
                label=p['name'][:100],
                description=f"{p['price_wl']} WorldLock | Stock: {p['stock_total']}"[:100],
                value=str(p['id']),
                emoji=shop_emoji
            ) for p in products[:25]
        ]
        if not opts:
            opts = [discord.SelectOption(label="Tidak ada produk", value="none")]
        super().__init__(placeholder="🛒 Click here to buy products", min_values=1, max_values=1,
                          options=opts, custom_id="sv_buy_dropdown")

    async def callback(self, interaction: discord.Interaction):
        sisa_interaction = check_cooldown(cooldown_interaction, interaction.user.id)
        if sisa_interaction > 0:
            await interaction.response.send_message(f"⏳ Tunggu **{int(sisa_interaction)} detik** lagi.", ephemeral=True)
            if isinstance(self.view, StoreView):
                new_view = StoreView(self.view.products)
                await interaction.message.edit(view=new_view)
            return

        if self.values[0] == "none":
            await interaction.response.send_message("❌ Belum ada produk.", ephemeral=True)
            if isinstance(self.view, StoreView):
                new_view = StoreView(self.view.products)
                await interaction.message.edit(view=new_view)
            return
        if is_blacklisted(interaction.user.id):
            await interaction.response.send_message("❌ Diblokir.", ephemeral=True)
            if isinstance(self.view, StoreView):
                new_view = StoreView(self.view.products)
                await interaction.message.edit(view=new_view)
            return
        sisa = check_cooldown(cooldown_buy, interaction.user.id)
        if sisa > 0:
            await interaction.response.send_message(f"⏳ Tunggu **{int(sisa)} detik** lagi.", ephemeral=True)
            if isinstance(self.view, StoreView):
                new_view = StoreView(self.view.products)
                await interaction.message.edit(view=new_view)
            return
        user = get_or_create_user(interaction.user.id)
        if not user.get("grow_id"):
            await interaction.response.send_message("❌ Set GrowID dulu!", ephemeral=True)
            if isinstance(self.view, StoreView):
                new_view = StoreView(self.view.products)
                await interaction.message.edit(view=new_view)
            return

        product_id  = int(self.values[0])
        prod        = supabase_admin.table("products").select("*").eq("id", product_id).execute()
        if not prod.data:
            await interaction.response.send_message("❌ Produk tidak ditemukan.", ephemeral=True)
            if isinstance(self.view, StoreView):
                new_view = StoreView(self.view.products)
                await interaction.message.edit(view=new_view)
            return
        product     = prod.data[0]
        stock_count = supabase_admin.table("stock_items").select("id", count="exact").eq("product_id", product_id).execute()
        if stock_count.count == 0:
            await interaction.response.send_message("❌ Stok habis.", ephemeral=True)
            if isinstance(self.view, StoreView):
                new_view = StoreView(self.view.products)
                await interaction.message.edit(view=new_view)
            return
        product["stock_total"] = stock_count.count
        set_cooldown(cooldown_buy, interaction.user.id)
        set_cooldown(cooldown_interaction, interaction.user.id)
        await interaction.response.send_modal(QtyModal(product, self.view))

# ====================== MENU DROPDOWN ======================
class MenuDropdown(discord.ui.Select):
    def __init__(self):
        global_emoji  = get_emoji("global", "🌍")
        qris_emoji    = get_emoji("QRIS", "💳")
        balance_emoji = get_emoji("worldlock", "🔒")
        opts = [
            discord.SelectOption(label="Set GrowID",    description="Set your GrowID",          value="setgrowid",   emoji="⚙️"),
            discord.SelectOption(label="Deposit",       description="View deposit info",         value="deposit",     emoji=global_emoji),
            discord.SelectOption(label="Deposit QRIS",  description="Top-up via QRIS",           value="qris",        emoji=qris_emoji),
            discord.SelectOption(label="Balance",       description="Check balance",             value="balance",     emoji=balance_emoji),
            discord.SelectOption(label="Update Harga",  description="[Admin] Ubah harga produk", value="updateprice", emoji="✏️"),
        ]
        super().__init__(placeholder="🛒 Click here to select menu", min_values=1, max_values=1,
                          options=opts, custom_id="sv_menu_dropdown")

    async def callback(self, interaction: discord.Interaction):
        sisa_interaction = check_cooldown(cooldown_interaction, interaction.user.id)
        if sisa_interaction > 0:
            await interaction.response.send_message(f"⏳ Tunggu **{int(sisa_interaction)} detik** lagi.", ephemeral=True)
            if isinstance(self.view, StoreView):
                new_view = StoreView(self.view.products)
                await interaction.message.edit(view=new_view)
            return

        choice = self.values[0]

        if choice == "setgrowid":
            sisa = check_cooldown(cooldown_setgrowid, interaction.user.id)
            if sisa > 0:
                await interaction.response.send_message(f"⏳ Tunggu **{int(sisa)} detik** lagi.", ephemeral=True)
            else:
                set_cooldown(cooldown_setgrowid, interaction.user.id)
                set_cooldown(cooldown_interaction, interaction.user.id)
                await interaction.response.send_modal(SetGrowIDModal())

        elif choice == "deposit":
            sisa = check_cooldown(cooldown_deposit, interaction.user.id)
            if sisa > 0:
                await interaction.response.send_message(f"⏳ Tunggu **{int(sisa)} detik** lagi.", ephemeral=True)
            else:
                set_cooldown(cooldown_deposit, interaction.user.id)
                set_cooldown(cooldown_interaction, interaction.user.id)
                user = get_or_create_user(interaction.user.id)
                if not user.get("grow_id"):
                    await interaction.response.send_message("❌ Set GrowID dulu!", ephemeral=True)
                else:
                    growtopia    = get_emoji("growtopia", "🌍")
                    global_emoji = get_emoji("global", "🌍")
                    crown_emoji  = get_emoji("crown", "👑")
                    bot_emoji    = get_emoji("newg1", "🤖")
                    book_emoji   = get_emoji("book", "📖")
                    deposit_bot   = get_deposit_bot()
                    deposit_world = get_deposit_world()
                    deposit_owner = get_deposit_owner()
                    msg  = f"{growtopia} DEPOSIT INFO {growtopia}\n"
                    msg += f"{global_emoji} World: `{deposit_world}`\n"
                    msg += f"{crown_emoji} Owner: `{deposit_owner}`\n"
                    msg += f"{bot_emoji} Bot: `{deposit_bot}`\n"
                    msg += f"{book_emoji} Note: SS IF NO BOT"
                    await interaction.response.send_message(msg, ephemeral=True)

        elif choice == "qris":
            sisa = check_cooldown(cooldown_qris, interaction.user.id)
            if sisa > 0:
                await interaction.response.send_message(f"⏳ Tunggu **{int(sisa)} detik** lagi.", ephemeral=True)
            else:
                set_cooldown(cooldown_qris, interaction.user.id)
                set_cooldown(cooldown_interaction, interaction.user.id)
                user = get_or_create_user(interaction.user.id)
                if not user.get("grow_id"):
                    await interaction.response.send_message("❌ Set GrowID dulu!", ephemeral=True)
                else:
                    await interaction.response.send_modal(QRISModal())

        elif choice == "balance":
            if is_blacklisted(interaction.user.id):
                await interaction.response.send_message("❌ Diblokir.", ephemeral=True)
            else:
                sisa = check_cooldown(cooldown_balance, interaction.user.id)
                if sisa > 0:
                    await interaction.response.send_message(f"⏳ Tunggu **{int(sisa)} detik** lagi.", ephemeral=True)
                else:
                    set_cooldown(cooldown_balance, interaction.user.id)
                    set_cooldown(cooldown_interaction, interaction.user.id)
                    user = get_or_create_user(interaction.user.id)
                    if not user.get("grow_id"):
                        await interaction.response.send_message("❌ Set GrowID dulu!", ephemeral=True)
                    else:
                        growtopia  = get_emoji("growtopia", "🌍")
                        user_emoji = get_emoji("user", "👤")
                        wl_emoji   = get_emoji("worldlock", "🔒")
                        msg  = f"{growtopia} BALANCE INFO {growtopia}\n"
                        msg += f"{user_emoji} User: {interaction.user.mention}\n"
                        msg += f"{user_emoji} GrowID: `{user['grow_id']}`\n"
                        msg += f"{wl_emoji} Balance: {wl_display(user['balance_wl'])}\n"
                        msg += f"© {STORE_NAME}"
                        await interaction.response.send_message(msg, ephemeral=True)

        elif choice == "updateprice":
            if not is_admin(interaction.user.id):
                await interaction.response.send_message("❌ Khusus admin.", ephemeral=True)
            else:
                set_cooldown(cooldown_interaction, interaction.user.id)
                await interaction.response.send_modal(UpdatePriceModal())

        if isinstance(self.view, StoreView):
            new_view = StoreView(self.view.products)
            try:
                await interaction.message.edit(view=new_view)
            except Exception as e:
                print(f"[MENU] Gagal reset view: {e}")

# ====================== STORE VIEW ======================
class StoreView(discord.ui.View):
    def __init__(self, products):
        super().__init__(timeout=None)
        self.products = products
        self.add_item(ProductDropdown(products))
        self.add_item(MenuDropdown())

# ---------------------- DEPOSIT EVENT ----------------------
@bot.event
async def on_message(message: discord.Message):
    await bot.process_commands(message)
    if message.channel.id != LOG_DEPOSIT_GT_ID:
        return
    if not message.content:
        return
    if "Deposit Masuk" in message.content:
        lines   = message.content.split("\n")
        grow_id = None
        item_line = None
        for line in lines:
            if "GrowID:" in line:
                grow_id   = line.split("GrowID:", 1)[1].strip().strip("`")
            if "Item:" in line:
                item_line = line.split("Item:", 1)[1].strip().strip("`")
        if grow_id and item_line:
            match = re.match(r"(\d+)x\s+(.+)", item_line)
            if match:
                amount    = int(match.group(1))
                item_name = match.group(2).strip()
                if item_name == "worlds lock":
                    item_name = "world lock"
                user = supabase_admin.table("users").select("*").ilike("grow_id", grow_id).execute()
                if user.data:
                    wl_value = 0
                    if item_name == "diamond lock":
                        wl_value = amount * 100
                    elif item_name == "world lock":
                        wl_value = amount
                    elif item_name == "blue gem lock":
                        wl_value = amount * 10000
                    if wl_value == 0:
                        return
                    balance_before = user.data[0]['balance_wl']
                    new_balance    = balance_before + wl_value
                    supabase_admin.table("users").update({"balance_wl": new_balance}).eq("discord_id", user.data[0]['discord_id']).execute()
                    await send_or_edit_status("DEPOSIT RECEIVED")
                    await asyncio.sleep(10)
                    await send_or_edit_status("WAITING FOR DEPOSIT CALL")
                    done_emoji = get_emoji("done", "✅")
                    wl_emoji   = get_emoji("worldlock", "🔒")
                    dl_emoji   = get_emoji("diamondlock", "💎")
                    item_emoji = dl_emoji if "diamond" in item_name else wl_emoji
                    try:
                        member = await bot.fetch_user(user.data[0]['discord_id'])
                        dm_embed = discord.Embed(title=f"{done_emoji} Deposit Diterima!", color=0x2ecc71)
                        dm_embed.add_field(name="Item",          value=f"{amount}x {item_name}", inline=True)
                        dm_embed.add_field(name=f"{wl_emoji} Ditambahkan", value=wl_display(wl_value),     inline=True)
                        dm_embed.add_field(name="\u200b",        value="\u200b",                           inline=False)
                        dm_embed.add_field(name="Saldo Sebelum", value=wl_display(balance_before),         inline=True)
                        dm_embed.add_field(name="Saldo Sesudah", value=wl_display(new_balance),            inline=True)
                        dm_embed.set_footer(text=STORE_NAME)
                        dm_embed.timestamp = datetime.now()
                        await member.send(embed=dm_embed)
                    except:
                        pass
                    if LOG_DEPOSIT_MASUK_ID:
                        log_ch = bot.get_channel(LOG_DEPOSIT_MASUK_ID)
                        if log_ch:
                            log_embed = discord.Embed(title=f"{done_emoji} Deposit GT Berhasil", color=0x2ecc71)
                            log_embed.add_field(name="👤 User",   value=f"<@{user.data[0]['discord_id']}>", inline=True)
                            log_embed.add_field(name="🌍 GrowID", value=f"`{grow_id}`",                     inline=True)
                            log_embed.add_field(name="\u200b",    value="\u200b",                           inline=False)
                            log_embed.add_field(name="📦 Item",   value=f"`{amount}x {item_name}`",         inline=True)
                            log_embed.add_field(name=f"{wl_emoji} Ditambah", value=wl_display(wl_value),   inline=True)
                            log_embed.add_field(name="\u200b",    value="\u200b",                           inline=False)
                            log_embed.add_field(name="Saldo Sebelum", value=wl_display(balance_before),     inline=True)
                            log_embed.add_field(name="Saldo Sesudah", value=wl_display(new_balance),        inline=True)
                            log_embed.set_footer(text=STORE_NAME)
                            log_embed.timestamp = datetime.now()
                            try:
                                await log_ch.send(embed=log_embed)
                            except Exception as e:
                                print(f"[DEPOSIT LOG] Gagal kirim log: {e}")
                    await refresh_all_stores()
                else:
                    ch = bot.get_channel(LOG_DEPOSIT_MASUK_ID)
                    if ch:
                        await ch.send(f"⚠️ Deposit dari GrowID `{grow_id}` gagal karena belum terdaftar.")

# ====================== RESET CONFIRM VIEW ======================
class ResetConfirmView(discord.ui.View):
    def __init__(self, interaction: discord.Interaction):
        super().__init__(timeout=60)
        self.interaction = interaction

    async def on_timeout(self):
        try:
            await self.interaction.edit_original_response(content="⏳ Waktu konfirmasi habis. Reset dibatalkan.", embed=None, view=None)
        except Exception:
            pass

    @discord.ui.button(label="✅ Ya, Reset Semua!", style=discord.ButtonStyle.danger)
    async def confirm_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.interaction.user.id:
            await interaction.response.send_message("❌ Bukan kamu yang meminta reset.", ephemeral=True)
            return
        for child in self.children:
            child.disabled = True
        await interaction.response.defer(ephemeral=True)
        await interaction.edit_original_response(content=None, embed=None, view=None)
        try:
            supabase_admin.table("topup_transactions").delete().neq("id", 0).execute()
            supabase_admin.table("users").delete().neq("discord_id", 0).execute()
            await interaction.followup.send("✅ **Semua data user dan transaksi berhasil direset!**\n⚠️ Semua user dan riwayat topup telah dihapus.", ephemeral=True)
            await refresh_all_stores()
        except Exception as e:
            await interaction.followup.send(f"❌ Gagal reset: {e}", ephemeral=True)

    @discord.ui.button(label="❌ Batal", style=discord.ButtonStyle.secondary)
    async def cancel_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.interaction.user.id:
            await interaction.response.send_message("❌ Bukan kamu yang meminta reset.", ephemeral=True)
            return
        for child in self.children:
            child.disabled = True
        await interaction.response.defer(ephemeral=True)
        await interaction.edit_original_response(content="❌ Reset dibatalkan.", embed=None, view=None)
        await interaction.followup.send("❌ Reset dibatalkan.", ephemeral=True)

# ====================== SLASH COMMANDS ======================
@bot.tree.command(name="store", description="Tampilkan panel toko")
async def cmd_store(interaction: discord.Interaction):
    try:
        await interaction.response.defer()
        prods = await get_all_products_with_stock()
        embed = store_embed(prods)
        await interaction.followup.send(embed=embed, view=StoreView(prods))
        msg   = await interaction.original_response()
        ch_id = interaction.channel_id
        if ch_id in store_refresh_tasks and store_refresh_tasks[ch_id][0]:
            store_refresh_tasks[ch_id][0].cancel()
        store_refresh_tasks[ch_id] = (None, msg)
        db_save_panel(ch_id, msg.id)
    except Exception as e:
        print(f"[STORE] Error: {e}")
        import traceback
        traceback.print_exc()
        try:
            await interaction.followup.send(f"❌ Error: {e}", ephemeral=True)
        except:
            pass

@bot.tree.command(name="balance", description="Cek saldo")
async def cmd_balance(interaction: discord.Interaction):
    user = get_or_create_user(interaction.user.id)
    embed = discord.Embed(title="💰 Saldo Kamu", color=0xf1c40f)
    embed.add_field(name="GrowID", value=f"`{user.get('grow_id','belum diset')}`")
    embed.add_field(name="Saldo",  value=wl_display(user.get('balance_wl', 0)))
    await interaction.response.send_message(embed=embed, ephemeral=True)

@bot.tree.command(name="setrate", description="[Admin] Set kurs 1 DL dalam IDR")
async def setrate(interaction: discord.Interaction, rate: int):
    if not is_admin(interaction.user.id):
        await interaction.response.send_message("❌ Khusus admin.", ephemeral=True)
        return
    supabase_admin.table("config").upsert({"key": "rate_dl", "value": str(rate)}).execute()
    await interaction.response.send_message(f"✅ Kurs 1 DL = {rate} IDR", ephemeral=True)

@bot.tree.command(name="setbotname", description="[Admin] Ubah nama bot yang ditampilkan")
async def set_bot_name(interaction: discord.Interaction, name: str):
    if not is_admin(interaction.user.id):
        await interaction.response.send_message("❌ Khusus admin.", ephemeral=True)
        return
    set_deposit_bot(name)
    await interaction.response.send_message(f"✅ Nama bot diubah menjadi `{name}`", ephemeral=True)
    await send_or_edit_status("WAITING FOR DEPOSIT CALL")

@bot.tree.command(name="setdepoworld", description="[Admin] Ubah nama world deposit yang ditampilkan")
async def set_depo_world(interaction: discord.Interaction, world: str):
    if not is_admin(interaction.user.id):
        await interaction.response.send_message("❌ Khusus admin.", ephemeral=True)
        return
    set_deposit_world(world)
    await interaction.response.send_message(f"✅ World deposit diubah menjadi `{world}`", ephemeral=True)
    await send_or_edit_status("WAITING FOR DEPOSIT CALL")

@bot.tree.command(name="setowner", description="[Admin] Ubah nama owner deposit yang ditampilkan")
async def set_owner(interaction: discord.Interaction, name: str):
    if not is_admin(interaction.user.id):
        await interaction.response.send_message("❌ Khusus admin.", ephemeral=True)
        return
    set_deposit_owner(name)
    await interaction.response.send_message(f"✅ Nama owner diubah menjadi `{name}`", ephemeral=True)

@bot.tree.command(name="uploadstock", description="[Admin] Upload stok via .txt")
@app_commands.describe(name="Nama produk", price_wl="Harga produk dalam WL", attachment="File .txt berisi stok", desc="Deskripsi produk (opsional)")
async def cmd_upload(interaction: discord.Interaction, name: str, price_wl: int, attachment: discord.Attachment, desc: str = None):
    await interaction.response.defer(ephemeral=True)
    if not is_admin(interaction.user.id):
        await interaction.followup.send("❌ Khusus admin.", ephemeral=True)
        return
    if not attachment.filename.endswith(".txt"):
        await interaction.followup.send("❌ Upload file .txt", ephemeral=True)
        return
    content = await attachment.read()
    lines   = [l.strip() for l in content.decode("utf-8").splitlines() if l.strip()]
    if not lines:
        await interaction.followup.send("❌ File kosong.", ephemeral=True)
        return
    prod = supabase_admin.table("products").select("id").eq("name", name).execute()
    if prod.data:
        product_id  = prod.data[0]['id']
        update_data = {"price_wl": price_wl}
        if desc is not None:
            update_data["description"] = desc
        supabase_admin.table("products").update(update_data).eq("id", product_id).execute()
        existing     = supabase_admin.table("stock_items").select("account_line").eq("product_id", product_id).execute()
        existing_set = {e['account_line'] for e in existing.data}
        new_items    = [{"product_id": product_id, "account_line": line} for line in lines if line not in existing_set]
        if new_items:
            supabase_admin.table("stock_items").insert(new_items).execute()
        added = len(new_items)
        total = supabase_admin.table("stock_items").select("id", count="exact").eq("product_id", product_id).execute().count
        await interaction.followup.send(f"✅ '{name}' harga {price_wl} WL, +{added} stok. Total: {total}", ephemeral=True)
    else:
        insert_data = {"name": name, "price_wl": price_wl, "sold_count": 0}
        if desc is not None:
            insert_data["description"] = desc
        new        = supabase_admin.table("products").insert(insert_data).execute()
        product_id = new.data[0]['id']
        stock_items = [{"product_id": product_id, "account_line": line} for line in lines]
        supabase_admin.table("stock_items").insert(stock_items).execute()
        await interaction.followup.send(f"✅ Produk '{name}' {price_wl} WL, {len(lines)} stok.", ephemeral=True)
    await refresh_all_stores()

@bot.tree.command(name="addsaldo", description="[Admin] Tambah saldo WL")
async def cmd_addsaldo(interaction: discord.Interaction, user: discord.User, amount_wl: int):
    if not is_admin(interaction.user.id):
        await interaction.response.send_message("❌ Khusus admin.", ephemeral=True)
        return
    user_data   = get_or_create_user(user.id)
    new_balance = user_data['balance_wl'] + amount_wl
    supabase_admin.table("users").update({"balance_wl": new_balance}).eq("discord_id", user.id).execute()
    await interaction.response.send_message(f"✅ +{amount_wl} WL ke {user.mention}", ephemeral=True)
    await refresh_all_stores()

@bot.tree.command(name="kurangsaldo", description="[Admin] Kurangi saldo WL")
async def cmd_kurangsaldo(interaction: discord.Interaction, user: discord.User, amount_wl: int):
    if not is_admin(interaction.user.id):
        await interaction.response.send_message("❌ Khusus admin.", ephemeral=True)
        return
    user_data = get_or_create_user(user.id)
    if user_data['balance_wl'] < amount_wl:
        await interaction.response.send_message("❌ Saldo tidak cukup.", ephemeral=True)
        return
    new_balance = user_data['balance_wl'] - amount_wl
    supabase_admin.table("users").update({"balance_wl": new_balance}).eq("discord_id", user.id).execute()
    await interaction.response.send_message(f"✅ -{amount_wl} WL dari {user.mention}", ephemeral=True)
    await refresh_all_stores()

@bot.tree.command(name="ceksaldo", description="[Admin] Lihat semua saldo")
async def ceksaldo(interaction: discord.Interaction):
    if not is_admin(interaction.user.id):
        await interaction.response.send_message("❌ Khusus admin.", ephemeral=True)
        return
    users = supabase_admin.table("users").select("discord_id, grow_id, balance_wl").order("discord_id").execute()
    msg   = "**📊 Daftar Saldo User (WL)**\n"
    for u in users.data:
        msg += f"👤 <@{u['discord_id']}> (`{u.get('grow_id','-')}`) : {wl_display(u['balance_wl'])}\n"
    await interaction.response.send_message(msg[:1900], ephemeral=True)

@bot.tree.command(name="hapusproduct", description="[Admin] Hapus produk")
async def hapusproduct(interaction: discord.Interaction, name: str):
    if not is_admin(interaction.user.id):
        await interaction.response.send_message("❌ Khusus admin.", ephemeral=True)
        return
    prod = supabase_admin.table("products").select("id").eq("name", name).execute()
    if not prod.data:
        await interaction.response.send_message(f"❌ Produk `{name}` tidak ditemukan.", ephemeral=True)
        return
    supabase_admin.table("stock_items").delete().eq("product_id", prod.data[0]['id']).execute()
    supabase_admin.table("products").delete().eq("id", prod.data[0]['id']).execute()
    await interaction.response.send_message(f"✅ Produk **{name}** dihapus.", ephemeral=True)
    await refresh_all_stores()

@bot.tree.command(name="setstatus", description="[Admin] Set status bot deposit")
@app_commands.choices(mode=[
    app_commands.Choice(name="Waiting",   value="WAITING FOR DEPOSIT CALL"),
    app_commands.Choice(name="Offline",   value="OFFLINE"),
    app_commands.Choice(name="Reconnect", value="RECONNECTING"),
])
async def cmd_setstatus(interaction: discord.Interaction, mode: str):
    if not is_admin(interaction.user.id):
        await interaction.response.send_message("❌ Khusus admin.", ephemeral=True)
        return
    await send_or_edit_status(mode)
    await interaction.response.send_message(f"✅ Status diupdate ke `{mode}`", ephemeral=True)

@bot.tree.command(name="editproduct", description="[Admin] Edit produk (code, description, price_rp)")
@app_commands.describe(name="Nama produk", code="Kode produk (opsional)", description="Deskripsi produk (opsional)", price_rp="Harga dalam Rupiah (opsional)")
async def edit_product(interaction: discord.Interaction, name: str, code: str = None, description: str = None, price_rp: int = None):
    if not is_admin(interaction.user.id):
        await interaction.response.send_message("❌ Khusus admin.", ephemeral=True)
        return
    update_data = {}
    if code        is not None: update_data["code"]        = code
    if description is not None: update_data["description"] = description
    if price_rp    is not None: update_data["price_rp"]    = price_rp
    if not update_data:
        await interaction.response.send_message("❌ Tidak ada data yang diubah.", ephemeral=True)
        return
    result = supabase_admin.table("products").update(update_data).eq("name", name).execute()
    if result.data:
        await interaction.response.send_message(f"✅ Produk **{name}** diperbarui.", ephemeral=True)
    else:
        await interaction.response.send_message(f"❌ Produk `{name}` tidak ditemukan.", ephemeral=True)
    await refresh_all_stores()

@bot.tree.command(name="hapususer", description="[Admin] Hapus user berdasarkan GrowID")
@app_commands.describe(grow_id="GrowID user yang akan dihapus")
async def hapususer(interaction: discord.Interaction, grow_id: str):
    if not is_admin(interaction.user.id):
        await interaction.response.send_message("❌ Khusus admin.", ephemeral=True)
        return
    await interaction.response.defer(ephemeral=True)
    grow_id = grow_id.strip()
    if not grow_id:
        await interaction.followup.send("❌ GrowID tidak boleh kosong.", ephemeral=True)
        return
    user_result = supabase_admin.table("users").select("*").ilike("grow_id", grow_id).execute()
    if not user_result.data:
        await interaction.followup.send(f"❌ User dengan GrowID `{grow_id}` tidak ditemukan.", ephemeral=True)
        return
    user       = user_result.data[0]
    discord_id = user["discord_id"]
    grow_id_db = user["grow_id"]
    supabase_admin.table("topup_transactions").delete().eq("user_id", discord_id).execute()
    supabase_admin.table("users").delete().eq("discord_id", discord_id).execute()
    await interaction.followup.send(
        f"✅ User dengan GrowID `{grow_id_db}` (Discord ID: {discord_id}) berhasil dihapus beserta semua riwayat transaksinya.",
        ephemeral=True
    )
    await refresh_all_stores()

@bot.tree.command(name="resetallusers", description="[Admin] Hapus SEMUA data user dan transaksi (tidak bisa dibatalkan!)")
async def reset_all_users(interaction: discord.Interaction):
    if not is_admin(interaction.user.id):
        await interaction.response.send_message("❌ Khusus admin.", ephemeral=True)
        return
    user_count = supabase_admin.table("users").select("id", count="exact").execute().count
    tx_count   = supabase_admin.table("topup_transactions").select("id", count="exact").execute().count
    embed = discord.Embed(
        title="⚠️ PERINGATAN: Reset Semua Data User!",
        description=f"Tindakan ini akan **menghapus permanen** semua data berikut:\n"
                    f"• **{user_count} user** (seluruh data saldo dan GrowID)\n"
                    f"• **{tx_count} transaksi topup** (riwayat QRIS)\n\n"
                    f"**Data produk dan stok tidak akan terhapus.**\n\n"
                    f"❗ **Proses ini tidak bisa dibatalkan!**",
        color=discord.Color.red()
    )
    embed.set_footer(text="Klik tombol di bawah untuk konfirmasi")
    view = ResetConfirmView(interaction)
    await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

# ---------------------- PREFIX COMMANDS ----------------------
@bot.command(name="blacklist")
async def cmd_bl(ctx, user: discord.User, *, reason: str = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Khusus admin.")
        return
    supabase_admin.table("blacklist").insert({"user_id": user.id, "reason": reason}).execute()
    await ctx.send(f"✅ {user.mention} diblokir.")

@bot.command(name="unblacklist")
async def cmd_ubl(ctx, user: discord.User):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Khusus admin.")
        return
    supabase_admin.table("blacklist").delete().eq("user_id", user.id).execute()
    await ctx.send(f"✅ {user.mention} diunblacklist.")

@bot.command(name="sync")
async def sync_cmd(ctx):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Khusus admin.")
        return
    try:
        guild  = discord.Object(id=ctx.guild.id)
        bot.tree.copy_global_to(guild=guild)
        synced = await bot.tree.sync(guild=guild)
        names  = [cmd.name for cmd in synced]
        await ctx.send(f"✅ Sync selesai! {len(synced)} command: `{', '.join(names)}`")
    except Exception as e:
        await ctx.send(f"❌ Error sync: {e}")

@bot.command(name="syncglobal")
async def sync_global_cmd(ctx):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Khusus admin.")
        return
    try:
        synced = await bot.tree.sync()
        names  = [cmd.name for cmd in synced]
        await ctx.send(f"✅ Global sync selesai! {len(synced)} command: `{', '.join(names)}`")
    except Exception as e:
        await ctx.send(f"❌ Error: {e}")

@bot.command(name="clearsync")
async def clear_sync_cmd(ctx):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Khusus admin.")
        return
    try:
        guild = discord.Object(id=ctx.guild.id)
        await bot.tree.sync(guild=guild)
        await bot.tree.sync()
        await ctx.send("✅ Semua command telah dibersihkan. Jalankan `!sync` sekarang untuk mendaftarkan ulang.")
    except Exception as e:
        await ctx.send(f"❌ Error: {e}")

# ====================== ANGKA BERJALAN ======================
def angka_berjalan():
    angka = 1
    naik  = True
    while True:
        print(f"\rAngka: {angka}", end="", flush=True)
        time.sleep(0.1)
        if naik:
            angka += 1
            if angka == 30: naik = False
        else:
            angka -= 1
            if angka == 1:  naik = True

# ====================== INTERNAL API UNTUK WEBHOOK ======================
from fastapi import FastAPI, Request
import uvicorn

internal_app = FastAPI()

@internal_app.post("/internal/topup")
async def internal_topup_callback(request: Request):
    data = await request.json()
    transaction_id = data.get("transaction_id")
    if not transaction_id:
        return {"status": "error", "message": "Missing transaction_id"}
    tx = supabase_admin.table("topup_transactions").select("*").eq("autogopay_txn_id", transaction_id).execute()
    if not tx.data:
        return {"status": "error", "message": "Transaction not found"}
    topup = tx.data[0]
    if topup["status"] == "settlement":
        return {"status": "success", "message": "Already processed"}
    supabase_admin.table("topup_transactions").update({
        "status": "settlement",
        "completed_at": datetime.now().isoformat()
    }).eq("id", topup["id"]).execute()
    user = supabase_admin.table("users").select("*").eq("discord_id", topup["user_id"]).execute()
    if user.data:
        wl          = topup.get("wl_amount", 0)
        new_balance = user.data[0]["balance_wl"] + wl
        supabase_admin.table("users").update({"balance_wl": new_balance}).eq("discord_id", topup["user_id"]).execute()
        future = asyncio.run_coroutine_threadsafe(
            notify_topup_success(topup["user_id"], wl, new_balance, topup["amount"], topup),
            bot.loop
        )
        try:
            await asyncio.wrap_future(future)
        except Exception as e:
            print(f"[INTERNAL TOPUP] notify error: {e}")
    return {"status": "success"}

async def notify_topup_success(user_id: int, wl: int, new_balance: int, amount: int, topup: dict):
    dm_channel_id = topup.get("dm_channel_id")
    dm_message_id = topup.get("dm_message_id")
    if dm_channel_id and dm_message_id:
        try:
            channel = bot.get_channel(dm_channel_id)
            if channel:
                try:
                    msg        = await channel.fetch_message(dm_message_id)
                    SEP        = "▬" * 12
                    done_emoji = get_emoji("done", "✅")
                    wl_emoji   = get_emoji("worldlock", "🔒")
                    success_embed = discord.Embed(
                        description=f"{SEP}\n"
                                    f"{done_emoji} Pembayaran Berhasil!\n"
                                    f"{wl_emoji} bertambah **{wl} WL**.\n"
                                    f"{wl_emoji} sekarang {wl_display(new_balance)}\n"
                                    f"© {STORE_NAME}\n"
                                    f"{SEP}",
                        color=0x2ecc71
                    )
                    await msg.edit(embed=success_embed, view=None)
                    print(f"[SUCCESS] Pesan QRIS di DM diedit menjadi sukses untuk user {user_id}")
                except discord.NotFound:
                    print(f"[SUCCESS] Pesan QRIS tidak ditemukan untuk user {user_id}")
                except Exception as e:
                    print(f"[SUCCESS] Gagal mengedit pesan QRIS: {e}")
        except Exception as e:
            print(f"[SUCCESS] Gagal mengakses channel DM: {e}")

    try:
        member     = await bot.fetch_user(user_id)
        done_emoji = get_emoji("done", "✅")
        await member.send(f"{done_emoji} Topup **{wl} WL** berhasil! Saldo sekarang {wl_display(new_balance)}")
    except Exception as e:
        print(f"[INTERNAL TOPUP] Gagal DM user {user_id}: {e}")

    if QRIS_LOG_CHANNEL_ID:
        ch = bot.get_channel(QRIS_LOG_CHANNEL_ID)
        if ch:
            book_emoji   = get_emoji("book", "📗")
            user_emoji   = get_emoji("user", "👤")
            global_emoji = get_emoji("global", "🌍")
            wl_emoji     = get_emoji("worldlock", "🔒")
            jam_emoji    = get_emoji("jam", "🕐")
            user_row     = supabase_admin.table("users").select("grow_id").eq("discord_id", user_id).execute()
            grow_id      = user_row.data[0]["grow_id"] if user_row.data and user_row.data[0].get("grow_id") else "-"
            embed = discord.Embed(title=f"{book_emoji} DEPOSIT SUCCESS", color=0x2ecc71)
            embed.add_field(name=f"{user_emoji} User",        value=f"<@{user_id}>",          inline=False)
            embed.add_field(name=f"{global_emoji} GrowID",    value=f"`{grow_id}`",            inline=False)
            embed.add_field(name=f"{wl_emoji} Amount",        value=f"Rp {rp_display(amount)} → {wl} WL", inline=False)
            embed.add_field(name=f"{wl_emoji} New Balance",   value=wl_display(new_balance),   inline=False)
            embed.add_field(name=f"{jam_emoji} Time",         value=f"<t:{int(datetime.now().timestamp())}:R>", inline=False)
            embed.set_footer(text=f"© {STORE_NAME}")
            try:
                await ch.send(embed=embed)
            except Exception as e:
                print(f"[INTERNAL TOPUP] Gagal kirim embed ke channel: {e}")

    await refresh_all_stores()

def run_internal_api():
    uvicorn.run(internal_app, host="127.0.0.1", port=int(os.getenv("INTERNAL_API_PORT", "8001")))

def run_webhook_server():
    from webhook_server import app as webhook_app
    uvicorn.run(webhook_app, host="0.0.0.0", port=int(os.getenv("WEBHOOK_PORT", "8000")))

def run_dashboard():
    from dashboard_server import app as dashboard_app
    uvicorn.run(dashboard_app, host="0.0.0.0", port=int(os.getenv("DASHBOARD_PORT", "8002")))

# ---------------------- ON READY ----------------------
@bot.event
async def on_ready():
    print(f"[BOT] Login sebagai: {bot.user} (ID: {bot.user.id})")
    print(f"[BOT] Terhubung ke {len(bot.guilds)} server")
    try:
        guild = discord.Object(id=GUILD_ID)
        bot.tree.copy_global_to(guild=guild)
        synced = await bot.tree.sync(guild=guild)
        print(f"[BOT] Auto-sync: {len(synced)} commands -> {[c.name for c in synced]}")
    except Exception as e:
        print(f"[BOT] Sync error: {e}")
    try:
        await send_or_edit_status("WAITING FOR DEPOSIT CALL")
    except Exception as e:
        print(f"[BOT] Status error: {e}")
    try:
        await restore_panels_from_db()
    except Exception as e:
        print(f"[BOT] Restore panels error: {e}")

# ---------------------- MAIN ----------------------
async def main():
    threading.Thread(target=angka_berjalan, daemon=True).start()
    t1 = threading.Thread(target=run_internal_api,    daemon=True)
    t2 = threading.Thread(target=run_webhook_server,  daemon=True)
    t1.start()
    t2.start()

    if os.getenv("ENABLE_DASHBOARD", "true").lower() == "true":
        t3 = threading.Thread(target=run_dashboard, daemon=True)
        t3.start()
        print(f"[BOT] Dashboard aktif di port {os.getenv('DASHBOARD_PORT', '8002')}")
    else:
        print("[BOT] Dashboard dimatikan (ENABLE_DASHBOARD=false)")

    asyncio.create_task(check_expired_transactions())
    asyncio.create_task(store_auto_refresh_loop())

    import time as _time
    _time.sleep(1)
    try:
        await bot.start(DISCORD_TOKEN)
    except discord.LoginFailure:
        print("[ERROR] Token Discord tidak valid!")
    except asyncio.CancelledError:
        pass
    except Exception as e:
        print(f"[ERROR] Gagal connect ke Discord: {e}")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("[BOT] Bot dihentikan.")
