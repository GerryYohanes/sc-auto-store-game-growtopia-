import os
from datetime import datetime
from fastapi import FastAPI, Request, HTTPException
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from dotenv import load_dotenv
from supabase import create_client, Client

load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_SERVICE_KEY = os.getenv("SUPABASE_SERVICE_KEY")

if not SUPABASE_URL or not SUPABASE_SERVICE_KEY:
    raise Exception("Missing SUPABASE_URL or SUPABASE_SERVICE_KEY in .env")

supabase: Client = create_client(SUPABASE_URL, SUPABASE_SERVICE_KEY)

app = FastAPI(title="Growtopia Store Dashboard")
templates = Jinja2Templates(directory="templates")

ADMIN_PASSWORD = os.getenv("DASHBOARD_PASSWORD", "admin123")

def verify_password(password: str):
    if password != ADMIN_PASSWORD:
        raise HTTPException(status_code=401, detail="Invalid password")

@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request, password: str = None):
    if not password:
        return templates.TemplateResponse("dashboard.html", {"request": request, "error": "Password required", "data": None})
    verify_password(password)

    # 1. Total user
    total_users = supabase.table("users").select("id", count="exact").execute().count

    # 2. Total produk
    total_products = supabase.table("products").select("id", count="exact").execute().count

    # 3. Total stok (dari stock_items)
    total_stock = supabase.table("stock_items").select("id", count="exact").execute().count

    # 4. Total topup sukses
    topup_success = supabase.table("topup_transactions").select("amount", count="exact").eq("status", "settlement").execute()
    total_topup_success = topup_success.count
    total_topup_nominal = sum([t["amount"] for t in topup_success.data]) if topup_success.data else 0

    # 5. Total penjualan (dari sold_count)
    products_data = supabase.table("products").select("sold_count").execute()
    total_sold = sum([p["sold_count"] for p in products_data.data]) if products_data.data else 0

    # 6. Revenue dalam WL (harga * sold_count)
    products_detail = supabase.table("products").select("name, price_wl, sold_count").execute()
    revenue_wl = sum([p["price_wl"] * p["sold_count"] for p in products_detail.data]) if products_detail.data else 0

    # 7. Statistik per produk untuk chart
    product_stats = [{"name": p["name"], "sold": p["sold_count"], "price": p["price_wl"]} for p in products_detail.data]

    # 8. Top 5 user dengan saldo tertinggi
    top_balances = supabase.table("users").select("discord_id, grow_id, balance_wl").order("balance_wl", desc=True).limit(5).execute()

    # 9. Transaksi topup terbaru (5 terakhir)
    recent_topups = supabase.table("topup_transactions").select("user_id, amount, wl_amount, status, created_at").order("created_at", desc=True).limit(5).execute()

    data = {
        "total_users": total_users or 0,
        "total_products": total_products or 0,
        "total_stock": total_stock or 0,
        "total_topup_success": total_topup_success or 0,
        "total_topup_nominal": total_topup_nominal or 0,
        "total_sold": total_sold or 0,
        "revenue_wl": revenue_wl or 0,
        "product_stats": product_stats,
        "top_balances": top_balances.data,
        "recent_topups": recent_topups.data,
        "last_update": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    return templates.TemplateResponse("dashboard.html", {"request": request, "data": data, "error": None})

if __name__ == "__main__":
    import uvicorn
    print("🚀 Dashboard berjalan di http://localhost:8080")
    uvicorn.run(app, host="0.0.0.0", port=8080)