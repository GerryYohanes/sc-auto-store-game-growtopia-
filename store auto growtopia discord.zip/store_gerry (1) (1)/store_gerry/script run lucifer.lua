﻿-- WEBHOOK DEPOSIT
webhook = "https://discord.com/api/webhooks/1515300656385359964/eZcxtYLvVlhz3UW6qmEwdcZGFA_ECu2tG_wq7iFYGwsgfqPVpQuaGCDgbmvR9EAAepS0"
-- WEBHOOK STATUS BOT (channel terpisah)
status_webhook = "https://discord.com/api/webhooks/1516495272186740782/UWoSH-QeKyLMZaLntXn6RQH04HeWjzm5p8exrOIH8e0yrXGhEAu0D5NdHcoTwogK7AWy"
-- API
-- Domain permanen (dev domain ngrok) -- TIDAK akan berubah, asal selalu di-run
-- pakai: ngrok http --url=https://easy-firmly-anteater.ngrok-free.app 8000
api_url = "https://easy-firmly-anteater.ngrok-free.app"

-- Status tracking (untuk heartbeat)
local lastHeartbeat = 0
local HEARTBEAT_INTERVAL = 300000 -- 5 menit (dalam ms)
local botStartTime = os.time()
local statusMessageId = nil -- ID pesan status yang akan di-edit terus, bukan kirim baru
local lastKnownConnected = nil -- nil = belum pernah dicek, true/false = state terakhir

function sendWebhook(text)
    local wh = Webhook.new(webhook)
    wh.username = "Growtopia Deposit"
    wh.content = text
    wh:send()
end

-- Kirim pesan baru ke webhook, return message_id dari response JSON (butuh ?wait=true)
function createStatusMessage(text)
    local client = HttpClient.new()
    client.url = status_webhook .. "?wait=true"
    client:setMethod(Method.post)
    client.headers["Content-Type"] = "application/json"

    -- escape karakter spesial buat JSON (quote, backslash, newline)
    local safe_text = text:gsub('\\', '\\\\'):gsub('"', '\\"'):gsub('\n', '\\n')

    client.content = string.format(
        '{"username":"Bot Status","content":"%s"}',
        safe_text
    )
    local ok, result = pcall(function() return client:request() end)
    if not ok or not result then
        print("[STATUS] Gagal create message: " .. tostring(result))
        return nil
    end
    if result.status ~= 200 then
        print("[STATUS] Create gagal, HTTP " .. tostring(result.status))
        return nil
    end
    -- Parse message id dari response body (cari pola "id":"angka_panjang" di awal JSON)
    local body = result.body or result.content or ""
    local id = body:match('"id"%s*:%s*"(%d+)"')
    return id
end

-- Edit pesan webhook yang sudah ada via PATCH
function editStatusMessage(message_id, text)
    local client = HttpClient.new()
    client.url = status_webhook .. "/messages/" .. message_id
    client:setMethod(Method.patch)
    client.headers["Content-Type"] = "application/json"

    local safe_text = text:gsub('\\', '\\\\'):gsub('"', '\\"'):gsub('\n', '\\n')

    client.content = string.format('{"content":"%s"}', safe_text)
    local ok, result = pcall(function() return client:request() end)
    if not ok or not result then
        return false
    end
    return result.status == 200
end

-- Fungsi utama: kirim pertama kali, lalu edit terus untuk panggilan selanjutnya
function sendStatusWebhook(text)
    if statusMessageId == nil then
        -- belum ada pesan, buat baru
        local id = createStatusMessage(text)
        if id then
            statusMessageId = id
            print("[STATUS] Pesan status dibuat, ID: " .. id)
        else
            print("[STATUS] Gagal buat pesan pertama, fallback ke webhook biasa")
            local wh = Webhook.new(status_webhook)
            wh.username = "Bot Status"
            wh.content = text
            wh:send()
        end
    else
        -- sudah ada pesan, coba edit
        local success = editStatusMessage(statusMessageId, text)
        if not success then
            print("[STATUS] Edit gagal (mungkin pesan dihapus manual), buat pesan baru")
            statusMessageId = nil
            local id = createStatusMessage(text)
            if id then
                statusMessageId = id
            end
        end
    end
end

function hitAPI(growid, totalWL)
    local ok, result = pcall(function()
        local client = HttpClient.new()
        -- FIX: dulu cuma "api_url" (root), padahal endpoint deposit ada di "/api/deposit".
        -- Root URL nggak punya route -> selalu balas 404 -> selalu "Deposit Failed".
        client.url = api_url .. "/api/deposit"
        client:setMethod(Method.post)
        client.headers["Content-Type"] = "application/json"
        client.headers["ngrok-skip-browser-warning"] = "1" -- jaga-jaga kalau ngrok kirim interstitial page
        client.content = string.format(
            '{"growid":"%s","totalWL":%d}',
            growid,
            totalWL
        )
        return client:request()
    end)

    if not ok or not result then
        print("[API] Request error / tidak bisa connect: " .. tostring(result))
        getBot():say("Deposit Failed! (server tidak bisa dihubungi)")
        sendWebhook("❌ Deposit Failed (server unreachable): " .. growid)
        return nil
    end

    print("[API] Status: " .. tostring(result.status))
    if result.status == 200 then
        getBot():say("Deposit Success! +" .. totalWL .. " WL")
        sendWebhook(
            "✅ **" ..
            growid ..
            "** deposit **" ..
            totalWL ..
            " WL**"
        )
    else
        getBot():say("Deposit Failed!")
        sendWebhook(
            "❌ Deposit Failed: " ..
            growid
        )
    end
    return result
end

function string:removeColors()
    return self:gsub("`.", "")
end

-- Cek status koneksi bot langsung menggunakan getBot().status
-- Berdasarkan testing: status = 1 artinya online/connected
function isBotConnected()
    local ok, status = pcall(function()
        return getBot().status
    end)
    if not ok or status == nil then
        return false
    end
    if type(status) == "number" then
        return status == 1
    end
    local s = tostring(status):lower()
    return s == "1" or s == "true" or s:find("online") or s:find("connect")
end

-- Cek apakah API/server backend masih hidup (cek endpoint /health, dan cek status-nya benar 200)
function checkAPIHealth()
    local ok, status = pcall(function()
        local client = HttpClient.new()
        client.url = api_url .. "/health"
        client.headers["ngrok-skip-browser-warning"] = "1"
        client:setMethod(Method.get)
        local result = client:request()
        return result.status
    end)
    return ok and status == 200
end

-- Ambil info real bot menggunakan getBot() API (lihat docs.txt)
function getBotInfoText()
    local bot = getBot()
    local ok, info = pcall(function()
        local world = "tidak terdeteksi"
        local ping = "?"
        local level = "?"
        local name = "?"
        local status = "?"

        pcall(function() name = bot.name end)
        pcall(function() level = bot.level end)
        pcall(function() ping = bot:getPing() end)
        pcall(function() status = bot.status end)

        local w_ok, w = pcall(function() return bot:getWorld() end)
        if w_ok and w ~= nil then
            local m1_ok, m1 = pcall(function() return w.name end)
            if m1_ok and m1 then
                world = tostring(m1)
            else
                local m2_ok, m2 = pcall(function() return bot.home_world end)
                if m2_ok and m2 and m2 ~= "" then
                    world = tostring(m2)
                end
            end
        else
            world = "tidak di world manapun"
        end

        return string.format(
            "👤 Bot: `%s`\n🌍 World: `%s`\n📶 Ping: `%sms`\n⭐ Level: `%s`\n📡 Status: `%s`",
            tostring(name), tostring(world), tostring(ping), tostring(level), tostring(status)
        )
    end)
    if ok then
        return info
    else
        return "⚠️ Gagal ambil info bot (mungkin tidak ter-connect)"
    end
end

-- Kirim status bot ke Discord (panggil ini secara periodik)
function sendHeartbeat()
    local uptime = os.time() - botStartTime
    local hours = math.floor(uptime / 3600)
    local minutes = math.floor((uptime % 3600) / 60)
    local apiOk = checkAPIHealth()
    local botOk = isBotConnected()
    local apiIcon = apiOk and "🟢" or "🔴"
    local apiText = apiOk and "API ONLINE" or "API TIDAK RESPON"
    local botIcon = botOk and "🟢" or "🔴"
    local botText = botOk and "GROWTOPIA CONNECTED" or "GROWTOPIA DISCONNECTED"
    local botInfo = getBotInfoText()

    sendStatusWebhook(
        botIcon .. " **Bot Growtopia: " .. botText .. "**\n" ..
        "⏱️ Uptime script: " .. hours .. "j " .. minutes .. "m\n" ..
        apiIcon .. " " .. apiText .. "\n\n" ..
        botInfo
    )
end

-- Cek perubahan status koneksi setiap loop (~6 detik), kirim alert INSTAN
-- hanya saat state berubah (connected->disconnected atau sebaliknya).
-- Pesan ini terpisah dari heartbeat (selalu pesan baru, supaya history disconnect tetap kelihatan).
function checkConnectionChange()
    local nowConnected = isBotConnected()

    if lastKnownConnected == nil then
        -- pertama kali cek, simpan state tanpa kirim alert
        lastKnownConnected = nowConnected
        return
    end

    if nowConnected ~= lastKnownConnected then
        if nowConnected then
            local wh = Webhook.new(status_webhook)
            wh.username = "Bot Status"
            wh.content = "🟢 **Bot Growtopia RECONNECTED!**\n" .. getBotInfoText()
            wh:send()
            print("[ALERT] Bot reconnected")
        else
            local wh = Webhook.new(status_webhook)
            wh.username = "Bot Status"
            wh.content = "🔴 **Bot Growtopia DISCONNECTED!**\n" .. getBotInfoText()
            wh:send()
            print("[ALERT] Bot disconnected")
        end
        lastKnownConnected = nowConnected
    end
end

-- Saat script pertama kali jalan, kirim notif startup
sendStatusWebhook("🟢 **Bot Lucifer dijalankan / restart**\n" .. getBotInfoText())

addEvent(Event.variantlist, function(variant, netid)
    if variant:get(0):getString() ~= "OnConsoleMessage" then
        return
    end
    local text = variant:get(1):getString()
    if not text:find("places") then
        return
    end
    local content = text:removeColors()
    local growid = content:match("%[%[(.-) places")
    local amount = content:match("places (%d+)")
    if not growid or not amount then
        return
    end
    amount = tonumber(amount)
    local totalWL = 0
    local lower = content:lower()
    if lower:find("blue gem lock") then
        totalWL = amount * 10000
    elseif lower:find("diamond lock") then
        totalWL = amount * 100
    elseif lower:find("world lock") then
        totalWL = amount
    end
    if totalWL <= 0 then
        return
    end
    growid = growid:lower()
    sendWebhook(
        "💰 **" ..
        growid ..
        "** deposit **" ..
        totalWL ..
        " WL**"
    )
    hitAPI(growid, totalWL)
end)

while true do
    -- Cek perubahan koneksi setiap loop (instant alert, ~6 detik)
    checkConnectionChange()

    listenEvents(5000)
    sleep(1000)

    -- Kirim heartbeat status setiap HEARTBEAT_INTERVAL
    local now = os.clock() * 1000
    if now - lastHeartbeat >= HEARTBEAT_INTERVAL then
        sendHeartbeat()
        lastHeartbeat = now
    end
end
