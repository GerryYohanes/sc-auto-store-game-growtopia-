-- ============================================================================
-- deposit_by_growid()
--
-- Fungsi ini menggantikan pola "baca saldo lalu tulis saldo" yang lama di
-- Python (webhook_server.py), yang nggak atomic dan rawan race condition
-- kalau ada dua deposit growid yang sama masuk nyaris bersamaan (lost
-- update -- salah satu deposit bisa "ketiban" / nggak ketambahin).
--
-- Dengan fungsi ini, pencarian user + update saldo terjadi dalam SATU
-- statement UPDATE di database. PostgreSQL otomatis ngasih row-level lock
-- pas UPDATE, jadi kalau ada 2 request nyaris bersamaan untuk growid yang
-- sama, salah satu bakal nunggu sampai yang pertama selesai -- nggak ada
-- lagi nilai yang "ketimpa".
--
-- CARA PAKAI:
--   1. Buka Supabase dashboard -> SQL Editor.
--   2. Paste seluruh isi file ini, lalu klik "Run". Cukup sekali saja,
--      nggak perlu diulang tiap deploy.
--   3. webhook_server.py (versi fixed) otomatis panggil fungsi ini lewat
--      supabase_admin.rpc("deposit_by_growid", {...}).
--
-- CATATAN TIPE DATA:
--   Fungsi ini menganggap kolom discord_id di tabel "users" bertipe
--   bigint (paling umum buat nyimpen Discord snowflake ID). Kalau di
--   project kamu kolomnya bertipe text/varchar, ganti "bigint" di baris
--   "discord_id bigint" pada definisi return table di bawah jadi "text".
-- ============================================================================

create or replace function deposit_by_growid(p_growid text, p_amount bigint)
returns table(discord_id bigint, new_balance bigint)
language plpgsql
as $$
begin
    if p_amount <= 0 then
        raise exception 'p_amount harus lebih besar dari 0';
    end if;

    return query
    update users
    set balance_wl = balance_wl + p_amount
    where grow_id ilike p_growid
    returning users.discord_id, users.balance_wl;
    -- Kalau nggak ada baris yang match (growid belum register), query di
    -- atas otomatis return 0 baris -- ini yang dicek di Python sebagai
    -- "GrowID not registered" (404).
end;
$$;
