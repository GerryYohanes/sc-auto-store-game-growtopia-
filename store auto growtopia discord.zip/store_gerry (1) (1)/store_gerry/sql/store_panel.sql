-- Jalankan ini di Supabase SQL Editor sekali saja
CREATE TABLE IF NOT EXISTS store_panels (
    id            SERIAL PRIMARY KEY,
    channel_id    BIGINT NOT NULL UNIQUE,
    message_id    BIGINT NOT NULL,
    updated_at    TIMESTAMPTZ DEFAULT NOW()
);
