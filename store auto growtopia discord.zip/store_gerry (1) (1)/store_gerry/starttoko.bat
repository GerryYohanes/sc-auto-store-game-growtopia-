@echo off
echo ==========================================
echo   Menjalankan NGROK + BOT.PY
echo ==========================================
echo.

echo [1/2] Membuka jendela NGROK...
start "NGROK" cmd /k "cd /d C:\Users\Administrator\Downloads\ngrok && ngrok http --url=https://easy-firmly-anteater.ngrok-free.app 8000"

echo Menunggu 5 detik supaya ngrok siap dulu sebelum bot.py jalan...
timeout /t 5 /nobreak >nul

echo [2/2] Membuka jendela BOT.PY...
start "BOT PY" cmd /k "cd /d C:\Users\Administrator\Downloads\store_gerry && python bot.py"

echo.
echo Selesai. Ada 2 jendela CMD baru yang terbuka:
echo   - Jendela "NGROK"  -> harus muncul baris "Forwarding ..."
echo   - Jendela "BOT PY" -> harus muncul "[BOT] Login sebagai: ..."
echo.
echo Jangan tutup kedua jendela itu selama toko mau online.
echo Jendela kecil ini (start_toko.bat) boleh ditutup, tidak masalah.
pause