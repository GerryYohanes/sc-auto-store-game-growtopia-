import os
import json
import hmac
import hashlib
import httpx
from fastapi import FastAPI, Request, HTTPException, BackgroundTasks
from fastapi.responses import JSONResponse
from dotenv import load_dotenv


load_dotenv()

AUTOGOPAY_API_KEY = os.getenv("AUTOGOPAY_API_KEY")
INTERNAL_API_URL = f"http://127.0.0.1:{os.getenv('INTERNAL_API_PORT', '8001')}/internal/topup"

app = FastAPI()


def verify_signature(payload_body: bytes, signature_header: str) -> bool:
    if not signature_header or not AUTOGOPAY_API_KEY:
        return False
    expected = hmac.new(AUTOGOPAY_API_KEY.encode(), payload_body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature_header)


@app.post("/webhook/autogopay")
async def autogopay_webhook(request: Request, background_tasks: BackgroundTasks):
    raw_body = await request.body()
    print(f"[AUTOGOPAY WEBHOOK] Raw body diterima: {raw_body[:500]!r}")

    # Kalau body kosong = AutoGoPay lagi test/verifikasi endpoint, langsung return 200
    if not raw_body:
        return {"success": True, "message": "Webhook endpoint active"}

    try:
        payload = json.loads(raw_body)
    except Exception as e:
        print(f"[AUTOGOPAY WEBHOOK] Gagal parse JSON: {e}")
        return {"success": True}

    # Verifikasi signature (skip kalau tidak ada signature = mode test AutoGoPay)
    signature = request.headers.get('X-Signature', '')
    if signature:
        if not verify_signature(raw_body, signature):
            print("[AUTOGOPAY WEBHOOK] Signature TIDAK valid, request ditolak.")
            raise HTTPException(status_code=401, detail="Invalid signature")

    event = payload.get('event')
    tx = payload.get('transaction', {})
    status = tx.get('status')
    # ID transaksi di payload webhook AutoGoPay namanya "transaction_id",
    # bukan "id" -- sebelumnya kode ini baca tx.get('id') yang selalu None,
    # jadi blok di bawah tidak pernah jalan walau status-nya cocok.
    transaction_id = tx.get('transaction_id')
    print(f"[AUTOGOPAY WEBHOOK] event={event} status={status} transaction_id={transaction_id}")

    if event == 'transaction.received':
        # AutoGoPay kirim status "PAID" di payload webhook (bukan "settlement" --
        # "settlement" itu vocab dari endpoint /qris/status, beda field/beda value).
        # Dicek .upper() juga buat jaga-jaga ada variasi huruf besar/kecil.
        if status and status.upper() == 'PAID':
            if transaction_id:
                print(f"[AUTOGOPAY WEBHOOK] Status PAID, forward ke internal API: {transaction_id}")
                async with httpx.AsyncClient() as client:
                    try:
                        resp = await client.post(INTERNAL_API_URL, json={"transaction_id": transaction_id}, timeout=10)
                        print(f"[AUTOGOPAY WEBHOOK] Internal API respond: {resp.status_code} {resp.text}")
                    except Exception as e:
                        print(f"[AUTOGOPAY WEBHOOK] Gagal hubungi internal API ({INTERNAL_API_URL}): {e}")
            else:
                print("[AUTOGOPAY WEBHOOK] Status PAID tapi transaction_id kosong, di-skip.")
        else:
            print(f"[AUTOGOPAY WEBHOOK] Status bukan PAID ({status}), di-skip.")
    else:
        print(f"[AUTOGOPAY WEBHOOK] Event bukan transaction.received ({event}), di-skip.")
    return {"success": True}


@app.post("/api/deposit")
async def deposit_from_growtopia(request: Request):
    """Endpoint untuk menerima deposit dari bot Growtopia (tanpa API key).

    PENTING: setiap response error di endpoint ini HARUS pakai status_code
    yang bukan 200, soalnya script Lua di bot Growtopia cuma ngecek HTTP
    status code buat nentuin "Deposit Success!" vs "Deposit Failed!" -- dia
    nggak baca field "status" di body JSON. Kalau endpoint ini balas 200
    padahal gagal, bot bakal bilang sukses ke pemain & ke Discord walau
    saldo sama sekali nggak nambah.
    """
    # 1. Body harus JSON yang valid
    try:
        data = await request.json()
    except Exception:
        return JSONResponse(status_code=400, content={"status": "error", "message": "Invalid JSON body"})

    growid = data.get("growid")
    totalWL = data.get("totalWL")

    # 2. Field wajib harus ada
    if not growid or totalWL is None:
        return JSONResponse(status_code=400, content={"status": "error", "message": "Missing growid or totalWL"})

    # 3. totalWL harus angka positif
    try:
        totalWL = int(totalWL)
    except (TypeError, ValueError):
        return JSONResponse(status_code=400, content={"status": "error", "message": "totalWL must be a number"})

    if totalWL <= 0:
        return JSONResponse(status_code=400, content={"status": "error", "message": "totalWL must be positive"})

    try:
        # Import supabase client di sini untuk menghindari circular import
        from supabase_client import supabase_admin

        # Cari + update saldo dalam SATU statement SQL atomic (lihat
        # sql/increment_balance.sql) -- jadi nggak ada lagi jeda
        # baca-saldo-lalu-tulis-saldo dari sisi Python, yang sebelumnya
        # rawan race condition / lost update kalau dua deposit growid
        # yang sama masuk nyaris bersamaan.
        result = supabase_admin.rpc(
            "deposit_by_growid",
            {"p_growid": growid, "p_amount": totalWL}
        ).execute()

        rows = result.data or []
        if not rows:
            # Tidak ada baris yang ke-update -> growid tidak terdaftar
            return JSONResponse(
                status_code=404,
                content={"status": "error", "message": f"GrowID {growid} not registered"}
            )

        row = rows[0]
        new_balance = row["new_balance"]
        discord_id = row["discord_id"]

        print(f"[DEPOSIT] {growid} (discord_id={discord_id}) +{totalWL} WL (new balance: {new_balance})")
        return JSONResponse(
            status_code=200,
            content={"status": "success", "new_balance": new_balance}
        )

    except Exception as e:
        print(f"[ERROR] /api/deposit: {e}")
        return JSONResponse(status_code=500, content={"status": "error", "message": str(e)})

@app.get("/health")
async def health():
    return {"status": "ok"}
